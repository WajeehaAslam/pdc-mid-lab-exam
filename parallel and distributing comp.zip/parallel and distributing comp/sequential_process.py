import os
import time
from PIL import Image, ImageDraw, ImageFont

# --- Parent directory containing all 4 folders ---
parent_dir = r"C:\Users\pc\Desktop\parallel and distributing comp"

# --- Only process these folders ---
folders_to_process = [
    "cars-20251027T101016Z-1-001",
    "Flowers-20251027T101023Z-1-001",
    "Cat-20251027T101016Z-1-001",
    "dogs-20251027T101019Z-1-001"
]

# --- Output directory ---
output_dir = os.path.join(parent_dir, "output_seq")
os.makedirs(output_dir, exist_ok=True)

# --- Global counters ---
total_images = 0
folder_stats = {}

# --- Start total timer ---
total_start = time.perf_counter()

for folder_name in folders_to_process:
    folder_path = os.path.join(parent_dir, folder_name)
    if not os.path.isdir(folder_path):
        print(f"⚠️ Folder not found: {folder_name}")
        continue

    start_time = time.perf_counter()
    count = 0

    # Process each image in the folder
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                count += 1
                input_path = os.path.join(root, file)

                # Maintain folder structure in output
                relative_path = os.path.relpath(root, parent_dir)
                output_folder = os.path.join(output_dir, relative_path)
                os.makedirs(output_folder, exist_ok=True)

                try:
                    img = Image.open(input_path).convert("RGB")
                    img = img.resize((128, 128))

                    # --- Add watermark ---
                    draw = ImageDraw.Draw(img)
                    text = "pdc"
                    try:
                        font = ImageFont.truetype("arial.ttf", 15)
                    except IOError:
                        font = ImageFont.load_default()

                    bbox = draw.textbbox((0, 0), text, font=font)
                    text_width = bbox[2] - bbox[0]
                    text_height = bbox[3] - bbox[1]
                    x = img.width - text_width - 5
                    y = img.height - text_height - 5
                    draw.text((x, y), text, fill=(255, 255, 255), font=font)

                    # Save processed image
                    output_path = os.path.join(output_folder, file)
                    img.save(output_path)

                except Exception as e:
                    print(f"Error processing {input_path}: {e}")

    end_time = time.perf_counter()
    elapsed = end_time - start_time
    folder_stats[folder_name] = (count, elapsed)
    total_images += count

# --- End total timer ---
total_end = time.perf_counter()
total_elapsed = total_end - total_start

# --- Print results ---
print("\nFolder-wise Processing Summary:")
print("--------------------------------")
for folder, (count, t) in folder_stats.items():
    print(f"{folder}: {count} images processed in {t:.2f} seconds")

print("--------------------------------")
print(f"Total images processed: {total_images}")
print(f"Total Sequential Processing Time: {total_elapsed:.2f} seconds")




# Folder-wise Processing Summary:       
# --------------------------------
# cars-20251027T101016Z-1-001: 21 images processed in 0.15 seconds
# Flowers-20251027T101023Z-1-001: 27 images processed in 0.15 seconds
# Cat-20251027T101016Z-1-001: 23 images processed in 0.13 seconds
# dogs-20251027T101019Z-1-001: 23 images processed in 0.12 seconds
# --------------------------------
# Total images processed: 94
# Total Sequential Processing Time: 0.55 seconds