import os
import time
import multiprocessing
from PIL import Image, ImageDraw, ImageFont

# Configuration
parent_dir = r"C:\Users\pc\Desktop\parallel and distributing comp"
folders_to_process = [
    "cars-20251027T101016Z-1-001",
    "Flowers-20251027T101023Z-1-001",
    "Cat-20251027T101016Z-1-001",
    "dogs-20251027T101019Z-1-001"
]
output_dir = os.path.join(parent_dir, "output_distributed")

def process_image(args):
    input_path, relative_path, output_dir = args
    try:
        output_folder = os.path.join(output_dir, relative_path)
        os.makedirs(output_folder, exist_ok=True)
        file = os.path.basename(input_path)
        img = Image.open(input_path).convert("RGB")
        img = img.resize((128, 128))
        draw = ImageDraw.Draw(img)
        text = "Animals"
        try:
            font = ImageFont.truetype("arial.ttf", 15)
        except Exception:
            font = ImageFont.load_default()
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = img.width - text_width - 5
        y = img.height - text_height - 5
        draw.text((x, y), text, fill=(255, 255, 255), font=font)
        output_path = os.path.join(output_folder, file)
        img.save(output_path)
    except Exception as e:
        print(f"Error processing {input_path}: {e}")

def collect_image_list():
    lst = []
    for folder_name in folders_to_process:
        folder_path = os.path.join(parent_dir, folder_name)
        if not os.path.isdir(folder_path):
            continue
        for root, _, files in os.walk(folder_path):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    rel = os.path.relpath(root, parent_dir)
                    lst.append((os.path.join(root, file), rel, output_dir))
    return lst

def node_task(node_id, image_list, result_queue):
    start = time.perf_counter()
    for args in image_list:
        process_image(args)
    end = time.perf_counter()
    duration = end - start
    result_queue.put((node_id, len(image_list), duration))

if __name__ == "__main__":
    os.makedirs(output_dir, exist_ok=True)
    all_images = collect_image_list()
    total_images = len(all_images)
    print(f"Total images found: {total_images}")

    mid = total_images // 2
    node1_images = all_images[:mid]
    node2_images = all_images[mid:]

    manager = multiprocessing.Manager()
    result_queue = manager.Queue()

    print("\nStarting simulated distributed processing...")

    start_total = time.perf_counter()

    p1 = multiprocessing.Process(target=node_task, args=(1, node1_images, result_queue))
    p2 = multiprocessing.Process(target=node_task, args=(2, node2_images, result_queue))

    p1.start()
    p2.start()
    p1.join()
    p2.join()

    end_total = time.perf_counter()
    total_time = end_total - start_total

    results = []
    while not result_queue.empty():
        results.append(result_queue.get())

    results.sort(key=lambda x: x[0])

    for node_id, count, duration in results:
        print(f"Node {node_id} processed {count} images in {duration:.2f}s")

    print(f"Total distributed time: {total_time:.2f}s")

    sequential_time = 18.24  # Example sequential time (replace with your Task 1 result)
    efficiency = sequential_time / total_time
    print(f"Efficiency: {efficiency:.2f}x over sequential")
