import os
import time
from PIL import Image, ImageDraw, ImageFont
from concurrent.futures import ProcessPoolExecutor

# Configuration
parent_dir = r"C:\Users\pc\Desktop\parallel and distributing comp"
folders_to_process = [
    "cars-20251027T101016Z-1-001",
    "Flowers-20251027T101023Z-1-001",
    "Cat-20251027T101016Z-1-001",
    "dogs-20251027T101019Z-1-001"
]
output_dir = os.path.join(parent_dir, "output_parallel")

def process_image(args):
    input_path, relative_path, output_dir = args
    try:
        output_folder = os.path.join(output_dir, relative_path)
        os.makedirs(output_folder, exist_ok=True)
        file = os.path.basename(input_path)
        img = Image.open(input_path).convert("RGB")
        img = img.resize((128, 128))
        draw = ImageDraw.Draw(img)
        text = "Animals"
        try:
            font = ImageFont.truetype("arial.ttf", 15)
        except Exception:
            font = ImageFont.load_default()
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = img.width - text_width - 5
        y = img.height - text_height - 5
        draw.text((x, y), text, fill=(255, 255, 255), font=font)
        output_path = os.path.join(output_folder, file)
        img.save(output_path)
    except Exception as e:
        print(f"Error processing {input_path}: {e}")

def collect_image_list():
    lst = []
    for folder_name in folders_to_process:
        folder_path = os.path.join(parent_dir, folder_name)
        if not os.path.isdir(folder_path):
            continue
        for root, _, files in os.walk(folder_path):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    rel = os.path.relpath(root, parent_dir)
                    lst.append((os.path.join(root, file), rel, output_dir))
    return lst

def run_with_workers(image_list, workers):
    if workers == 1:
        start = time.perf_counter()
        for args in image_list:
            process_image(args)
        end = time.perf_counter()
        return end - start
    else:
        start = time.perf_counter()
        with ProcessPoolExecutor(max_workers=workers) as ex:
            list(ex.map(process_image, image_list))
        end = time.perf_counter()
        return end - start

if __name__ == "__main__":
    image_list = collect_image_list()
    total_images = len(image_list)
    print(f"Total images found: {total_images}")

    os.makedirs(output_dir, exist_ok=True)

    worker_configs = [1, 2, 4, 8]
    times = {}

    for w in worker_configs:
        print(f"\nProcessing with {w} worker{'s' if w>1 else ''}...")
        t = run_with_workers(image_list, w)
        times[w] = t
        print(f"Time with {w} workers: {t:.4f} seconds")

    base = times[1] if times.get(1, 0) > 0 else min(times.values())
    print("\nWorkers | Time (s) | Speedup")
    print("-------- | -------- | -------")
    for w in worker_configs:
        time_w = times.get(w, 0.0)
        speedup = base / time_w if time_w > 0 else 0.0
        print(f"{w} | {time_w:.2f} | {speedup:.2f}x")




# output :

# Total images found: 94

# Processing with 1 worker...
# Time with 1 workers: 0.9094 seconds

# Processing with 2 workers...
# Time with 2 workers: 1.1552 seconds

# Processing with 4 workers...
# Time with 4 workers: 0.9716 seconds

# Processing with 8 workers...
# Time with 8 workers: 1.6263 seconds

# Workers | Time (s) | Speedup
# -------- | -------- | -------
# 1 | 0.91 | 1.00x
# 2 | 1.16 | 0.79x
# 4 | 0.97 | 0.94x
# 8 | 1.63 | 0.56x